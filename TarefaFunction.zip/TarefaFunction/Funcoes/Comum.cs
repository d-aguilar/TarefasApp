﻿using Microsoft.Azure.WebJobs.Host;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TarefaFunction.Funcoes
{
    public class Comum
    {
        public static async Task<HttpResponseMessage> GetBadRequest(HttpRequestMessage req, TraceWriter log)
        {
            HttpResponseMessage response;
            response = req.CreateResponse(HttpStatusCode.MethodNotAllowed, $"Método não permitido.");

            return response;
        }

    }
}
